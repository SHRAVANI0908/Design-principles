package org.example.Operations;

public class Operations {
    public float addition(float firstNumber, float secondNumber)
    {
        return firstNumber+secondNumber;
    }

    public float subtraction(float firstNumber, float secondNumber)
    {
        return firstNumber-secondNumber;
    }

    public float multiplication(float firstNumber, float secondNumber)
    {
        return firstNumber*secondNumber;
    }

    public float division(float firstNumber, float secondNumber)
    {
        return firstNumber/secondNumber;
    }

    public float remainder(float firstNumber, float secondNumber)
    {
        return firstNumber%secondNumber;
    }
}
